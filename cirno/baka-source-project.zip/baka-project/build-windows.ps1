# 在 Windows PowerShell 执行： .\build-windows.ps1
# 需要 Python 3 和 Pillow；第一次运行前请执行：py -m pip install Pillow
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path 'cirno.gif')) {
    throw '请把透明背景的 cirno.gif 放在本目录，再运行此脚本。'
}
py .\bake_cirno.py --size 40x20 --fps 10
if ($LASTEXITCODE -ne 0) { throw '动画预烘焙失败' }
py .\build_assets.py --size 40x20
if ($LASTEXITCODE -ne 0) { throw '资源嵌入文件生成失败' }
Write-Host '成功：现在将 baka.c 和 assets.h 复制到 Alpine，编译得到单文件 baka。'
