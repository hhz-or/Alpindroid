# Windows 原生编译 baka.exe。支持 MSYS2 UCRT64 GCC 或 Visual Studio cl.exe。
# PowerShell 用法： .\build-windows.ps1 [-Size 40x20] [-Fps 10] [-SkipBake] [-RequireAnimation]
param(
    [string]$Size = '40x20',
    [double]$Fps = 10,
    [switch]$SkipBake,
    [switch]$RequireAnimation,
    [ValidateSet('auto', 'gcc', 'cl')]
    [string]$Compiler = 'auto'
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Invoke-Python([string[]]$ArgsToPass) {
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        & $py.Source @ArgsToPass
    } else {
        $python = Get-Command python -ErrorAction SilentlyContinue
        if (-not $python) { throw '需要 Python 3。请安装 Python，或者使用项目中已有的 assets.h 编译静态素材。' }
        & $python.Source @ArgsToPass
    }
    if ($LASTEXITCODE -ne 0) { throw "Python 命令执行失败，退出码：$LASTEXITCODE" }
}

$gif = Test-Path (Join-Path $PSScriptRoot 'cirno.gif')
$didBake = $false
if ($gif -and -not $SkipBake) {
    Write-Host '检测到 cirno.gif，开始预烘焙动画...' -ForegroundColor Cyan
    Invoke-Python -ArgsToPass @('.\bake_cirno.py', '--size', $Size, '--fps', "$Fps")
    $didBake = $true
}

$modes = @('mono', 'braille-mono', 'ascii', 'braille', 'normal')
$missing = @($modes | Where-Object { -not (Test-Path "baked/$_-$Size.cirno") })
if ($RequireAnimation -and $missing.Count -ne 0) {
    throw ('缺少动画缓存：' + ($missing -join ', ') + '。请把 cirno.gif 放在项目根目录重新运行。')
}

# 有素材时重新生成 assets.h；没有 GIF 也没有动画缓存时，允许用内置静态素材先测试。
$hasAnyBake = (@($modes | Where-Object { Test-Path "baked/$_-$Size.cirno" })).Count -gt 0
if ($didBake -or $hasAnyBake -or -not (Test-Path 'assets.h')) {
    $assetArgs = @('.\build_assets.py', '--size', $Size)
    if ($missing.Count -ne 0) { $assetArgs += '--allow-missing' }
    Invoke-Python -ArgsToPass $assetArgs
} else {
    Write-Host '未发现 GIF / .cirno 缓存，使用随项目提供的 assets.h（仅静态文字可测试）。' -ForegroundColor Yellow
}

# 优先使用 GCC；兼容 Windows PowerShell 直接定位 MSYS2 UCRT64 里的 gcc.exe。
$gccPath = $null
foreach ($candidate in @('C:\msys64\ucrt64\bin\gcc.exe', 'C:\msys2\ucrt64\bin\gcc.exe')) {
    if (Test-Path $candidate) { $gccPath = $candidate; break }
}
if (-not $gccPath) {
    $gccCommand = Get-Command gcc -ErrorAction SilentlyContinue
    if ($gccCommand) { $gccPath = $gccCommand.Source }
}
$clCommand = Get-Command cl -ErrorAction SilentlyContinue
$clPath = if ($clCommand) { $clCommand.Source } else { $null }

if ($Compiler -eq 'gcc' -and -not $gccPath) { throw '找不到 GCC。安装 MSYS2 的 UCRT64 GCC，或传入 -Compiler cl。' }
if ($Compiler -eq 'cl' -and -not $clPath) { throw '找不到 cl.exe。请使用 Visual Studio 的 Developer PowerShell 或 x64 Native Tools Command Prompt。' }
if ($Compiler -eq 'auto') {
    if ($gccPath) { $Compiler = 'gcc' }
    elseif ($clPath) { $Compiler = 'cl' }
    else {
        throw '找不到 C 编译器。推荐安装 MSYS2 UCRT64：pacman -S --needed mingw-w64-ucrt-x86_64-gcc'
    }
}

Write-Host "开始编译 baka.exe（$Compiler）..." -ForegroundColor Cyan
if ($Compiler -eq 'gcc') {
    & $gccPath -Os -std=c11 -Wall -Wextra -static -s -o baka.exe baka.c -lm
} else {
    & $clPath /nologo /O2 /utf-8 /std:c11 /Fe:baka.exe baka.c
}
if ($LASTEXITCODE -ne 0) { throw "编译失败，退出码：$LASTEXITCODE" }
if (-not (Test-Path 'baka.exe')) { throw '编译器未生成 baka.exe。' }
Write-Host '编译成功：baka.exe' -ForegroundColor Green
Write-Host '测试：.\baka.exe  /  .\baka.exe baka  /  .\baka.exe --list'
if ($missing.Count -ne 0) {
    Write-Host '注意：部分动画未嵌入；静态模式可测试，动画模式需要先放入 cirno.gif 再重新烘焙。' -ForegroundColor Yellow
}
